package Controller;


public abstract class Controller {
    public abstract void add(Object o);
    public abstract void remove(Object o);
}
