package Interface;
public abstract class Form {
    protected static boolean ticketFormOpened = false;
    public abstract void run();
}
